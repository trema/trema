#ifndef CONTROL_H
#define CONTROL_H

#include "oflops.h"

int setup_control_channel(oflops_context *ctx);


#endif
